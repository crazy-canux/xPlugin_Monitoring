#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Copyright (C) 2015 Faurecia (China) Holding Co.,Ltd.

All rights reserved.
Name: check_wmi.py
Author: Canux CHENG canuxcheng@gmail.com
Version: V1.0.0.0
Time: Mon 08 Aug 2016 04:43:40 PM CST

Description:
    [1.0.0.0] 20160728 init for basic function.
"""
import os
import sys
import logging
import argparse
# try:
#     import cPickle as pickle
# except:
#     import pickle
import subprocess
import csv
import datetime

# import sh


class Nagios(object):

    """Basic class for nagios."""

    def __init__(self, name=None, version='1.0.0.0', description='For wmi'):
        """Init class Nagios."""
        self.__name = os.path.basename(sys.argv[0]) if not name else name
        self.__version = version
        self.__description = description

        # Init the log
        logging.basicConfig(format='[%(levelname)s] (%(module)s) %(message)s')
        self.logger = logging.getLogger("wmi")
        self.logger.setLevel(logging.INFO)

        # Init the argument
        self.__define_options()
        self.define_sub_options()
        self.__parse_options()

        # Init the logger
        if self.args.debug:
            self.logger.setLevel(logging.DEBUG)
        self.logger.debug("===== BEGIN DEBUG =====")
        self.logger.debug("Init Nagios")

        # Init output data.
        self.output_ = ""
        self.shortoutput = ""
        self.longoutput = []
        self.perfdata = []

        # End the debug.
        if self.__class__.__name__ == "Nagios":
            self.logger.debug("===== END DEBUG =====")

    def __define_options(self):
        self.parser = argparse.ArgumentParser(description="Plugin for wmi.")
        self.parser.add_argument('-V', '--version',
                                 action='version',
                                 version='{0} {1}'.format(self.__name, self.__version),
                                 help='Show version')
        self.parser.add_argument('-D', '--debug',
                                 action='store_true',
                                 required=False,
                                 help='Show debug informations.',
                                 dest='debug')

    def define_sub_options(self):
        self.wmi_parser = self.parser.add_argument_group('wmi options',
                                                         'For wmi connect.')
        self.subparsers = self.parser.add_subparsers(title='Action:',
                                                     description='The mode.',
                                                     help='Options for mode.')

    def __parse_options(self):
        try:
            self.args = self.parser.parse_args()
        except Exception as e:
            self.unknown("parser args error: %s" % e)

    def output(self, substitute=None, long_output_limit=20):
        if not substitute:
            substitute = {}

        self.output_ += "{0}".format(self.shortoutput)
        if self.longoutput:
            self.output_ = self.output_.rstrip("\n")
            self.output_ += " | \n{0}".format(
                "\n".join(self.longoutput[:long_output_limit]))
            if long_output_limit:
                self.output_ += "\n(...showing only first {0} lines, " \
                    "{1} elements remaining...)".format(
                        long_output_limit,
                        len(self.longoutput[long_output_limit:]))
        if self.perfdata:
            self.output_ = self.output_.rstrip("\n")
            self.output_ += " | \n{0}".format(" ".join(self.perfdata))
        return self.output_.format(**substitute)

    def ok(self, msg):
        raise NagiosOk(msg)

    def warning(self, msg):
        raise NagiosWarning(msg)

    def critical(self, msg):
        raise NagiosCritical(msg)

    def unknown(self, msg):
        raise NagiosUnknown(msg)


class NagiosOk(Exception):

    def __init__(self, msg):
        print "OK - %s" % msg
        raise SystemExit(0)


class NagiosWarning(Exception):

    def __init__(self, msg):
        print "WARNING - %s" % msg
        raise SystemExit(1)


class NagiosCritical(Exception):

    def __init__(self, msg):
        print "CRITICAL - %s" % msg
        raise SystemExit(2)


class NagiosUnknown(Exception):

    def __init__(self, msg):
        print "UNKNOWN - %s" % msg
        raise SystemExit(3)


class Wmi(Nagios):

    """Basic class for wmi."""

    def __init__(self, *args, **kwargs):
        super(Wmi, self).__init__(*args, **kwargs)
        self.logger.debug("Init wmi")

    def query(self, wql):
        """Connect by wmi and run wql."""
        try:
            self.__wql = ['wmic', '-U',
                          self.args.domain + '\\' + self.args.adminuser + '%' + self.args.password,
                          '//' + self.args.host,
                          '--namespace', self.args.namespace,
                          '--delimiter', self.args.delimiter,
                          wql]
            self.logger.debug("wql: {}".format(self.__wql))
            self.__output = subprocess.check_output(self.__wql)
            self.logger.debug("output: {}".format(self.__output))
            self.__wmi_output = self.__output.splitlines()[1:]
            self.logger.debug("wmi_output: {}".format(self.__wmi_output))
            self.__csv_header = csv.DictReader(self.__wmi_output, delimiter='|')
            self.logger.debug("csv_header: {}".format(self.__csv_header))
            return list(self.__csv_header)
        except subprocess.CalledProcessError as e:
            self.unknown("Connect by wmi and run wql error: %s" % e)

    def define_sub_options(self):
        super(Wmi, self).define_sub_options()
        self.wmi_parser.add_argument('-H', '--host',
                                     required=True,
                                     help='wmi server host.',
                                     dest='host')
        self.wmi_parser.add_argument('-d', '--domain',
                                     required=False,
                                     help='wmi server domain.',
                                     dest='domain')
        self.wmi_parser.add_argument('-u', '--adminuser',
                                     required=True,
                                     help='wmi admin username',
                                     dest='adminuser')
        self.wmi_parser.add_argument('-p', '--password',
                                     required=True,
                                     help='wmi login password.',
                                     dest='password')
        self.wmi_parser.add_argument('-n', '--namespace',
                                     default='root\cimv2',
                                     required=False,
                                     help='namespace for wmi, default is %(default)s',
                                     dest='namespace')
        self.wmi_parser.add_argument('-s', '--delimiter',
                                     default='|',
                                     required=False,
                                     help='delimiter for wmi, default is %(default)s',
                                     dest='delimiter')


class FileNumber(Wmi):

    r"""Count the number of file in the folder.

    Example:
    check_wmi.py -H HOSTNAME -d [Domain] -u USER -p [password] --debug filenumber -d 'C:' -r
    check_wmi.py -H HOSTNAME -d [Domain] -u USER -p [password] --debug filenumber -d 'C:' -p '\\' -f '%%' -e '%%' -r
    check_wmi.py -H HOSTNAME -d [Domain] -u USER -p [password] --debug filenumber -d 'C:' -p '\\Windows\\' -f '%%' -e '%%' -r
    """

    def __init__(self, *args, **kwargs):
        super(FileNumber, self).__init__(*args, **kwargs)
        self.logger.debug("Init FileNumber")

    def define_sub_options(self):
        super(FileNumber, self).define_sub_options()
        self.fn_parser = self.subparsers.add_parser('filenumber',
                                                    help='Count file number.',
                                                    description='Options\
                                                    for filenumber.')
        self.fn_parser.add_argument('-q', '--query',
                                    required=False,
                                    help='wql for wmi.',
                                    dest='query')
        self.fn_parser.add_argument('-d', '--drive',
                                    required=True,
                                    help='the windows driver, like C:',
                                    dest='drive')
        self.fn_parser.add_argument('-p', '--path',
                                    default="\\\\",
                                    required=False,
                                    help='the folder, default is %(default)s',
                                    dest='path')
        self.fn_parser.add_argument('-f', '--filename',
                                    default="%%",
                                    required=False,
                                    help='the filename, default is %(default)s',
                                    dest='filename')
        self.fn_parser.add_argument('-e', '--extension',
                                    default="%%",
                                    required=False,
                                    help='the file extension, default is %(default)s',
                                    dest='extension')
        self.fn_parser.add_argument('-R', '--recursion',
                                    action='store_true',
                                    help='Recursive count file under path.',
                                    dest='recursion')
        self.fn_parser.add_argument('-w', '--warning',
                                    default=0,
                                    type=int,
                                    required=False,
                                    help='Warning number of file, default is %(default)s',
                                    dest='warning')
        self.fn_parser.add_argument('-c', '--critical',
                                    default=0,
                                    type=int,
                                    required=False,
                                    help='Critical number of file, default is %(default)s',
                                    dest='critical')

    def __get_file(self, path):
        self.wql_file = "SELECT Name FROM CIM_DataFile WHERE Drive='{0}' \
            AND Path='{1}' AND FileName LIKE '{2}' AND Extension LIKE '{3}'".format(self.args.drive,
                                                                                    path,
                                                                                    self.args.filename,
                                                                                    self.args.extension)
        self.file_data = self.query(self.wql_file)
        [self.file_list.append(file_data) for file_data in self.file_data]
        self.logger.debug("file_data: {}".format(self.file_data))
        return len(self.file_data), self.file_list

    def __get_folder(self, path):
        self.wql_folder = "SELECT FileName FROM CIM_Directory WHERE Drive='{0}' AND Path='{1}'".format(self.args.drive,
                                                                                                       path)
        self.number, self.file_list = self.__get_file(path)
        self.count += self.number
        self.folder_data = self.query(self.wql_folder)
        self.logger.debug("folder_data: {}".format(self.folder_data))
        if self.folder_data:
            for folder in self.folder_data:
                self.new_path = (folder['Name'].split(":")[1] + "\\").replace("\\", "\\\\")
                self.__get_folder(self.new_path)
        return self.count, self.file_list

    def filenumber_handle(self):
        """Get the number of file in the folder."""
        self.file_list = []
        self.count = 0

        if self.args.recursion:
            self.__result, self.__file_list = self.__get_folder(self.args.path)
        else:
            self.__result, self.__file_list = self.__get_file(self.args.path)

        status = self.ok

        # Compare the vlaue.
        if self.__result > self.args.warning:
            status = self.warning
        if self.__result > self.args.critical:
            status = self.critical

        # Output
        self.shortoutput = "Found {0} files in {1}.".format(self.__result,
                                                            self.args.path)
        self.logger.debug("file_list: {}".format(self.__file_list))
        [self.longoutput.append(file_data.get('Name')) for file_data in self.__file_list]
        self.perfdata.append("{path}={result};{warn};{crit};0;".format(
            crit=self.args.critical,
            warn=self.args.warning,
            result=self.__result,
            path=self.args.path))

        # Return status with message to Nagios.
        status(self.output(long_output_limit=None))
        self.logger.debug("Return status and exit to Nagios.")


class FileAge(Wmi):

    r"""Get the file age, compare with the current date and time.

    Example:
    check_wmi.py -H HOSTNAME -d [Domain] -u USER -p [password] --debug fileage -d 'C:' -r
    check_wmi.py -H HOSTNAME -d [Domain] -u USER -p [password] --debug fileage -d 'C:' -p '\\' -f '%%' -e '%%' -r
    check_wmi.py -H HOSTNAME -d [Domain] -u USER -p [password] --debug fileage -d 'C:' -p '\\Windows\\' -f '%%' -e '%%' -r
    """

    def __init__(self, *args, **kwargs):
        super(FileAge, self).__init__(*args, **kwargs)
        self.logger.debug("Init FileAge")

    def define_sub_options(self):
        super(FileAge, self).define_sub_options()
        self.fa_parser = self.subparsers.add_parser('fileage',
                                                    help='Get file age.',
                                                    description='Options\
                                                    for fileage.')
        self.fa_parser.add_argument('-q', '--query',
                                    required=False,
                                    help='wql for wmi.',
                                    dest='query')
        self.fa_parser.add_argument('-d', '--drive',
                                    required=True,
                                    help='the windows driver, like C:',
                                    dest='drive')
        self.fa_parser.add_argument('-p', '--path',
                                    default="\\\\",
                                    required=False,
                                    help='the folder, default is %(default)s',
                                    dest='path')
        self.fa_parser.add_argument('-f', '--filename',
                                    default="%%",
                                    required=False,
                                    help='the filename, default is %(default)s',
                                    dest='filename')
        self.fa_parser.add_argument('-e', '--extension',
                                    default="%%",
                                    required=False,
                                    help='the file extension, default is %(default)s',
                                    dest='extension')
        self.fa_parser.add_argument('-R', '--recursion',
                                    action='store_true',
                                    help='Recursive count file under path.',
                                    dest='recursion')
        self.fa_parser.add_argument('-w', '--warning',
                                    default=30,
                                    type=int,
                                    required=False,
                                    help='Warning minute of file, default is %(default)s',
                                    dest='warning')
        self.fa_parser.add_argument('-c', '--critical',
                                    default=60,
                                    type=int,
                                    required=False,
                                    help='Critical minute of file, default is %(default)s',
                                    dest='critical')

    def __get_file(self, path):
        self.wql_file = "SELECT LastModified FROM CIM_DataFile WHERE Drive='{0}' \
            AND Path='{1}' AND FileName LIKE '{2}' AND Extension LIKE '{3}'".format(self.args.drive,
                                                                                    path,
                                                                                    self.args.filename,
                                                                                    self.args.extension)
        self.file_data = self.query(self.wql_file)
        [self.file_list.append(file_data) for file_data in self.file_data]
        self.logger.debug("file_data: {}".format(self.file_data))
        return self.file_list

    def __get_folder(self, path):
        self.wql_folder = "SELECT FileName FROM CIM_Directory WHERE Drive='{0}' AND Path='{1}'".format(self.args.drive,
                                                                                                       path)
        self.file_list = self.__get_file(path)
        self.folder_data = self.query(self.wql_folder)
        self.logger.debug("folder_data: {}".format(self.folder_data))
        if self.folder_data:
            for folder in self.folder_data:
                self.new_path = (folder['Name'].split(":")[1] + "\\").replace("\\", "\\\\")
                self.__get_folder(self.new_path)
        return self.file_list

    def __get_current_datetime(self):
        """Get current datetime for every file."""
        self.wql_time = "SELECT LocalDateTime FROM Win32_OperatingSystem"
        self.current_time = self.query(self.wql_time)
        # [{'LocalDateTime': '20160824161431.977000+480'}]'
        self.current_time_string = str(self.current_time[0].get('LocalDateTime').split('.')[0])
        # '20160824161431'
        self.current_time_format = datetime.datetime.strptime(self.current_time_string, '%Y%m%d%H%M%S')
        # param: datetime.datetime(2016, 8, 24, 16, 14, 31) -> type: datetime.datetime
        return self.current_time_format

    def fileage_handle(self):
        """Get the number of file in the folder."""
        self.file_list = []
        self.ok_file = []
        self.warn_file = []
        self.crit_file = []

        if self.args.recursion:
            self.__file_list = self.__get_folder(self.args.path)
        else:
            self.__file_list = self.__get_file(self.args.path)
        self.logger.debug("file_list: {}".format(self.__file_list))
        # [{'LastModified': '20160824142017.737101+480', 'Name': 'd:\\test\\1.txt'},
        # {'LastModified': '20160824142021.392101+480', 'Name': 'd:\\test\\2.txt'},
        # {'LastModified': '20160824142106.460101+480', 'Name': 'd:\\test\\test1\\21.txt'}]

        for file_dict in self.__file_list:
            self.filename = file_dict.get('Name')
            self.logger.debug("===== start to compare {} =====".format(self.filename))

            self.file_datetime_string = file_dict.get('LastModified').split('.')[0]
            self.file_datetime = datetime.datetime.strptime(self.file_datetime_string, '%Y%m%d%H%M%S')
            self.logger.debug("file_datetime: {}".format(self.file_datetime))

            self.current_datetime = self.__get_current_datetime()
            self.logger.debug("current_datetime: {}".format(self.current_datetime))

            self.__delta_datetime = self.current_datetime - self.file_datetime
            self.logger.debug("delta_datetime: {}".format(self.__delta_datetime))
            self.logger.debug("warn_datetime: {}".format(datetime.timedelta(minutes=self.args.warning)))
            self.logger.debug("crit_datetime: {}".format(datetime.timedelta(minutes=self.args.critical)))
            if self.__delta_datetime > datetime.timedelta(minutes=self.args.critical):
                self.crit_file.append(self.filename)
            elif self.__delta_datetime > datetime.timedelta(minutes=self.args.warning):
                self.warn_file.append(self.filename)
            else:
                self.ok_file.append(self.filename)

        status = self.ok

        # Compare the vlaue.
        if self.warn_file:
            status = self.warning
        if self.crit_file:
            status = self.critical

        # Output
        self.shortoutput = "Found {0} files out of date.".format(len(self.crit_file))
        if self.crit_file:
            self.longoutput.append("===== Critical File out of date ====")
        [self.longoutput.append(filename) for filename in self.crit_file if self.crit_file]
        if self.warn_file:
            self.longoutput.append("===== Warning File out of date ====")
        [self.longoutput.append(filename) for filename in self.warn_file if self.warn_file]
        if self.ok_file:
            self.longoutput.append("===== OK File out of date ====")
        [self.longoutput.append(filename) for filename in self.ok_file if self.ok_file]
        self.perfdata.append("{path}={result};{warn};{crit};0;".format(
            crit=self.args.critical,
            warn=self.args.warning,
            result=len(self.crit_file),
            path=self.args.drive + self.args.path))

        # Return status with message to Nagios.
        status(self.output(long_output_limit=None))
        self.logger.debug("Return status and exit to Nagios.")


class Pool(FileNumber, FileAge):

    """Register your own class here."""

    def __init__(self, *args, **kwargs):
        super(Pool, self).__init__(*args, **kwargs)


def main():
    """Register your own mode and handle method here."""
    plugin = Pool()
    arguments = sys.argv[1:]
    if 'filenumber' in arguments:
        plugin.filenumber_handle()
    elif 'fileage' in arguments:
        plugin.fileage_handle()
    else:
        plugin.unknown("Unknown actions.")

if __name__ == "__main__":
    main()
