=======
xplugin
=======

xplugin include tons of plugins support nagios and tools based on nagios.

`[awesome-monitoring] <https://github.com/crazy-canux/awesome-monitoring>`_.

--------------
How to install
--------------

plugin/plugins/* based on libs/monitoring, so you have to put this lib in "/usr/lib/python2.7/dist-packages".

plugin/\*.py is independent, you can just use it.

----------
How to use
----------

Put these plugin in some where like "/usr/lib/monitoring/plugins".

--------------
How to extends
--------------

You can use the API in plugin/libs/monitoring to write your own plugins.

============
Contribution
============

`[Contribution] <https://github.com/crazy-canux/xplugin/blob/master/CONTRIBUTING.rst>`_

=======
Authors
=======

`[Authors] <https://github.com/crazy-canux/xplugin/blob/master/AUTHORS.rst>`_

=======
License
=======

`[License] <https://github.com/crazy-canux/xPlugin_Monitoring/blob/master/LICENSE>`_
